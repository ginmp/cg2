/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

import com.jme3.app.SimpleApplication;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.bullet.util.CollisionShapeFactory;

import com.jme3.light.AmbientLight;
import com.jme3.light.DirectionalLight;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Box;
import com.jme3.shadow.DirectionalLightShadowRenderer;
import jogo.util.Cor;
import jogo.entidades.Base;
import jogo.entidades.Parede;
import jogo.mapas.Mapa;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import java.util.Map;

import jogo.controle.BuildWall;
import jogo.controle.Controle;
import jogo.controle.ControlePlayer;
import jogo.controle.ControleGeral;
import jogo.entidades.Player;
import jogo.entidades.Teleport;
import jogo.estrategias.ai.FugirAI_Melhorado;
import jogo.estrategias.ai.SeguirAI;
import jogo.mapas.gerador.GeradorMapa;
import jogo.mapas.gerador.GeradorSimples;
import jogo.mapas.gerador.GeradorVazio;
import jogo.util.Ponto;

/**
 *
 * @author inmp
 */
public class Jogo extends SimpleApplication
        implements IJogo {

    private BulletAppState bulletAppState;

    private Node node_paredes = new Node();
    private Node node_teleports = new Node();
    private Node node_itens = new Node();

    private float item_rotation = 0.1f;
    private int points;

    private Spatial player1;
    private Spatial player2;

    private GeradorMapa gerador;
    private Controle controlePlayer1;
    private Controle controlePlayer2;

    //============
    public static long FPS = 60;
    public static int MULT = 1;

    public static int RES = 1000;
//    private int WIDTH = RES;
//    private int HEIGHT = RES;
    private final int offset_tela_mapa = 11 * MULT;
    private double cam_dist = -20 * MULT;
    private double angCam = -5;

    private Mapa mapa;

    private Jogando jogando;

    private int camGiro;
    private int cntMapaSalvo;

    private ControleGeral controleGeral;

    private boolean rodadaPlayer1;
    private boolean mudarCamera;
    private boolean girarCamera;
    private boolean diminuirAngulo;
    private boolean aumentarAngulo;
    private boolean follow;
    private int angInicial;
    private boolean altAng;
    private boolean stop;

    public static void main(String[] args) {
        Jogo app = new Jogo();
        // app.showSettings = false;
        app.start();
    }

    @Override
    public void simpleInitApp() {

        bulletAppState = new BulletAppState();
        stateManager.attach(bulletAppState);
//        bulletAppState.getPhysicsSpace().addCollisionListener(this);

        initJogo();

        createLigth();

        desenharPiso();
        desenharMapa();
        desenharTeleports();
        createItens();

        desenharPlayer1();
        desenharPlayer2();

        System.out.println(getCamera().getLocation());
        int n = 1;
        int h = 55 * MULT;

        Vector3f camPos = new Vector3f(n * 22 * MULT, h, n * 22 * MULT);

        this.getCamera().setLocation(camPos);

        camPos.setY(0);
//        this.getCamera().lookAt(camPos, new Vector3f(0, -1, 0));

        disableFlyCam();

        controleGeral = new ControleGeral();

        rodadaPlayer1 = true;

    }

    private void disableFlyCam() {

        float sqrt2 = (float) (Math.sqrt(2) / 2);
        this.getCamera().setRotation(new Quaternion(0.0f, -sqrt2, sqrt2, 0.0f));
        flyCam.setEnabled(false);
    }

    @Override
    public void simpleUpdate(float tpf) {
        //TODO: add update code
        jogar();
        updateItems();

    }

    @Override
    public void simpleRender(RenderManager rm) {
        //TODO: add render code
    }

    private void createLigth() {

        /**
         * A white, directional light source
         */
        DirectionalLight sun = new DirectionalLight();
        sun.setDirection((new Vector3f(-.5f, -1f, 0)).normalizeLocal());
        sun.setColor(ColorRGBA.White);
        rootNode.addLight(sun);
        /**
         * A white ambient light source.
         */
        AmbientLight ambient = new AmbientLight();
        ambient.setColor(ColorRGBA.White);
        rootNode.addLight(ambient);

        /* this shadow needs a directional light */
        DirectionalLightShadowRenderer dlsr = new DirectionalLightShadowRenderer(assetManager, 1024, 2);
        dlsr.setLight(sun);
        viewPort.addProcessor(dlsr);

    }

    private void detach(Spatial sp) {
        rootNode.detachChild(sp);
        RigidBodyControl r = sp.getControl(RigidBodyControl.class);
        bulletAppState.getPhysicsSpace().remove(r);
    }

    public Jogo() {
        this(new GeradorSimples(), new ControlePlayer(), new FugirAI_Melhorado());
//        this(new GeradorSimples(), new ControlePlayer(), new SeguirAI());
//        this(new GeradorSimples(), new SeguirAI(), new FugirAI_Melhorado());
//        this(new GeradorSimples(), new SeguirAI(), new SeguirAI());

//        gerador = new GeradorVazio();
    }

    public Jogo(GeradorMapa gerador, Controle controlePlayer1, Controle controlePlayer2) {
        this.gerador = gerador;
        this.controlePlayer1 = controlePlayer1;
        this.controlePlayer2 = controlePlayer2;
    }

    private void initJogo() {

        player1 = assetManager.loadModel("Models/Oto/Oto.mesh.xml");
        player1.setName("p1");

        float dim = .25f;
        player1.setLocalScale(dim, dim, dim);

        player2
                = assetManager.loadModel("Models/Ninja/Ninja.mesh.xml");
        //assetManager.loadModel("Models/gltf/duck/Duck.gltf");

        player2.setName("p2");

        dim = .015f;
        player2.setLocalScale(dim, dim, dim);

        rootNode.attachChild(player1);
        rootNode.attachChild(player2);

        if (controlePlayer1 instanceof ControlePlayer) {
            //tela.addKeyListener((ControlePlayer) controlePlayer1);
            ((ControlePlayer) controlePlayer1).initKeys(inputManager);
        }

        mapa = new Mapa(gerador, controlePlayer1, controlePlayer2);
        mapa.gerarMapa();

        jogando = new Jogando(mapa);
    }

    private void createItens() {
        Spatial item;
        for (Ponto ponto : mapa.getItens().values()) {
            item = assetManager.loadModel("Models/gltf/duck/Duck.gltf");
            item.setLocalTranslation(2 * ponto.getX(), ponto.getZ(), 2 * ponto.getY());
            node_itens.attachChild(item);
        }
        rootNode.attachChild(node_itens);
    }

    private void updateItems() {
        Spatial detach = null;
        Vector3f player1_position = player1.getLocalTranslation().clone();
        Vector3f item_position;
        player1_position.setY(0);
        for (Spatial item : node_itens.getChildren()) {

            if (detach == null) {
                item_position = item.getLocalTranslation().clone();
                item_position.setY(0);
                if (player1_position.equals(item_position)) {
                    detach = item;
                }
            }
            item.rotate(0, item_rotation, 0);
        }

        if (detach != null) {
            node_itens.detachChild(detach);
            points++;
        }

    }

    private void restartGame() {
        detach(node_paredes);
        detach(node_teleports);
        detach(node_itens);

        node_paredes = new Node();
        node_teleports = new Node();
        node_itens = new Node();

        points = 0;
    }

    @Override
    public void jogar() {

        Player player1 = mapa.getPlayer1();
        Player player2 = mapa.getPlayer2();
        if (player1.getControle() instanceof BuildWall) {
            BuildWall bw = (BuildWall) player1.getControle();
            if (bw.isBuild()) {
                // texto(gl, "P1 Paredes : " + bw.getParedes(), -6, 10.1);
            }
        }
        if (player2.getControle() instanceof BuildWall) {
            BuildWall bw = (BuildWall) player2.getControle();
            if (bw.isBuild()) {
                //texto(gl, "P2 Paredes : " + bw.getParedes(), 6, 10.1);
            }
        }

        desenharPlayer1();
        desenharPlayer2();

        if (!controleGeral.isPause()) {
            if (!stop) {
                jogando.jogar();
            }
        } else {

//            texto(gl, "ESC : continuar", -5, 8);
//            texto(gl, "Q : sair", -5, 7);
//
//            texto(gl, "S : salvar mapa" + (cntMapaSalvo > 0 ? " - salvo = " + cntMapaSalvo : ""), -5, -1);
//            texto(gl, "END : reiniciar", -5, 0);
//            texto(gl, "C : mudar camera", -5, 1);
//            texto(gl, "G : girar mapa", -5, 2);
//            texto(gl, "F : follow", -5, 3);
//            texto(gl, "PG_UP : camera girar+", -5, 4);
//            texto(gl, "PG_DOWN : camera girar-", -5, 5);
//            texto(gl, "BK_SPACE : tela config", -5, 6);
//
//            texto(gl, "Click : construir/destruir parede", -5, -3);
//            texto(gl, "DEL : ativar/desativar destruir parede = " + controleGeral.isDelete(), -5, -4);
//            texto(gl, "SHIFT : ativar/desativar construcao/destruicao continua = " + controleGeral.isShift(), -5, -5);
//            texto(gl, "R : sempre reiniciar = " + controleGeral.isSempreReiniciar(), -5, -6);
//            texto(gl, "1 2 : mover player 1 ou 2" + (controleGeral.isMoverP1() ? " = mover " + 1 : controleGeral.isMoverP2() ? " = mover " + 2 : ""), -5, -7);
        }

        if (mapa.isNovoMapa()) {

            if (controleGeral.isSempreReiniciar()) {

                restartGame();

                controleGeral.reset();
                mapa.gerarMapa();
                stop = false;

                desenharMapa();
                desenharTeleports();
                createItens();

                desenharPlayer1();
                desenharPlayer2();

                return;
            }
            stop = true;

        }

        follow = controleGeral.isFollow();

        if (!follow && altAng) {
            camGiro = angInicial;
            altAng = false;
        }
        if (controleGeral.isNovoMapa()) {
            controleGeral.reset();
            mapa.gerarMapa();
            stop = false;
            return;
        }

        if (controleGeral.isMudarCamera()) {
            cam_dist = -30 * MULT + MULT - 1;
            mudarCamera = true;
        } else {
            cam_dist = -20 * MULT + MULT - 1;
            mudarCamera = false;
        }

        if (controleGeral.isGirarCamera()) {
            girarCamera = true;
        }

        if (controleGeral.isAumentar()) {
            aumentarAngulo = true;
        }

        if (controleGeral.isDiminuir()) {
            diminuirAngulo = true;
        }

        if (controleGeral.isSair()) {
            System.exit(0);
        }

        if (!controleGeral.isMoverP1() && !controleGeral.isMoverP2()) {
            if (controleGeral.isShift()) {
                Ponto mp = controleGeral.getMousePoint();
                if (!mp.equals(player1.getPonto()) && !mp.equals(player2.getPonto())) {
                    if (!controleGeral.isDelete()) {
                        mapa.construirParede(mp, new Cor(0.6f, 0.3f, 0.15f));
                    } else {
                        mapa.destruirParede(mp);
                    }
                }
            }

            if (controleGeral.isMouseClick()) {
                Ponto mp = controleGeral.getMousePoint();
                if (!mp.equals(player1.getPonto()) && !mp.equals(player2.getPonto())) {
                    if (!controleGeral.isDelete()) {
                        mapa.construirParede(mp, new Cor(0.6f, 0.3f, 0.15f));
                    } else {
                        mapa.destruirParede(mp);
                    }
                }
            }
        } else if (controleGeral.isMoverP1()) {
            if (controleGeral.isMouseClick()) {
                Ponto mp = controleGeral.getMousePoint();
                if (!mapa.getParedes().containsKey(Parede.getNome(mp))) {
                    player1.setPonto(mp);
                    stop = player1.colisao(player2);
                    mapa.setNovoMapa(stop);

                }
            }
        } else if (controleGeral.isMoverP2()) {
            if (controleGeral.isMouseClick()) {
                Ponto mp = controleGeral.getMousePoint();
                if (!mapa.getParedes().containsKey(Parede.getNome(mp))) {
                    player2.setPonto(mp);
                    stop = player1.colisao(player2);
                    mapa.setNovoMapa(stop);
                }
            }
        }

        if (controleGeral.isSalvar()) {
            salvarMapa();
            cntMapaSalvo++;
        }
        if (controleGeral.isFpsAdd() && FPS < 300) {
            FPS++;
        } else if (controleGeral.isFpsSub() && FPS > 1) {
            FPS--;
        }

        if (controleGeral.isTelaConfig()) {
//            destroy();
        }
    }

    private void desenharPiso() {

        String name = "piso";
        Box boxMesh = new Box(22f * MULT + 1, 1, 22f * MULT + 1);
        //Box boxMesh = new Box(2, -1, 2);
        Geometry boxGeo = new Geometry(name, boxMesh);
        Material boxMat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        boxMat.setTexture("ColorMap", assetManager.loadTexture("Textures/chess.jpg"));

        boxGeo.setMaterial(boxMat);

        boxGeo.setLocalTranslation(22 * MULT, -2, 22 * MULT);

        rootNode.attachChild(boxGeo);

        RigidBodyControl boxPhysicsNode = new RigidBodyControl(CollisionShapeFactory.createMeshShape(boxGeo), 0);
        boxGeo.addControl(boxPhysicsNode);
        bulletAppState.getPhysicsSpace().add(boxPhysicsNode);

    }

    private void desenharMapa() {

        float dim = 1f;

        for (Parede p : mapa.getParedes().values()) {
            String name = "parede";
            Box boxMesh = new Box(dim, dim, dim);
            Geometry boxGeo = new Geometry(name, boxMesh);
            Material boxMat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
            boxMat.setTexture("ColorMap", assetManager.loadTexture("Textures/cedrinho.jpg"));

            boxGeo.setMaterial(boxMat);

            boxGeo.setLocalTranslation(2 * p.getX(), p.getZ(), 2 * p.getY());

            RigidBodyControl boxPhysicsNode = new RigidBodyControl(CollisionShapeFactory.createMeshShape(boxGeo), 0);
            boxGeo.addControl(boxPhysicsNode);
            bulletAppState.getPhysicsSpace().add(boxPhysicsNode);

            node_paredes.attachChild(boxGeo);
        }
        rootNode.attachChild(node_paredes);
    }

    private void desenharTeleports() {
        float z = 1f;
        float dim = .5f;

        for (Teleport tp : mapa.getTeleports().values()) {
            Spatial sp = assetManager.loadModel("Models/Sign Post/Sign Post.mesh.xml");
            sp.setLocalScale(dim, dim, dim);
            sp.setLocalTranslation((tp.getX()) * 2, z, (tp.getY()) * 2);
            sp.setName(tp.getNome(tp.getPonto()));

            Material boxMat = new Material(assetManager, "Common/MatDefs/Light/Lighting.j3md");
            boxMat.setBoolean("UseMaterialColors", true);
//            boxMat.setColor("Ambient", ColorRGBA.Green);
            boxMat.setColor("Diffuse", new ColorRGBA(tp.getCor().getR(), tp.getCor().getG(), tp.getCor().getB(), .5f));
            sp.setMaterial(boxMat);

            node_teleports.attachChild(sp);

        }
        rootNode.attachChild(node_teleports);

    }

    private void desenharPlayer1() {
        translatedBase(player1, mapa.getPlayer1(), .15f);
    }

    private void desenharPlayer2() {
        translatedBase(player2, mapa.getPlayer2(), -1f);
    }

    private void translatedBase(Spatial sp, Base base, float z) {
        float offset = .75f;
        sp.setLocalTranslation((base.getX()) * 2, z, (base.getY()) * 2);

    }
//
//    private void texto(GL2 gl, String str, double x, double y) {
//
//        gl.glPushMatrix();
//        {
//            gl.glLoadIdentity();
//
//            gl.glTranslated(0, 0, -20);
//            gl.glTranslated(x, y, 3);
//
//            gl.glColor3d(1, .8, .2);
//
//            gl.glDisable(GL2.GL_LIGHTING);
//
//            glu.gluOrtho2D(0, WIDTH, 0, HEIGHT);
//            gl.glRasterPos2i(0, 0);
//
//            gl.glEnable(GL2.GL_LIGHTING);
//
//            glut.glutBitmapString(GLUT.BITMAP_TIMES_ROMAN_24, str);
//        }
//        gl.glPopMatrix();
//
//    }
//
//    private void initTela(Component canvas) {
//        tela.setSize(WIDTH, HEIGHT);
//        tela.setResizable(false);
//        tela.setUndecorated(true);
//
//        tela.getContentPane().add(canvas);
//
//        tela.setVisible(true);
//
//        tela.setLocation(
//                (int) (Toolkit.getDefaultToolkit().getScreenSize().getWidth()) / 2
//                - tela.getWidth() / 2,
//                (int) (Toolkit.getDefaultToolkit().getScreenSize().getHeight()) / 2
//                - tela.getHeight() / 2);
//        tela.setAlwaysOnTop(true);
//
//        tela.addKeyListener(controleGeral);
//        tela.addMouseListener(controleGeral);
//        tela.addMouseMotionListener(controleGeral);
//
//        tela.addWindowListener(new WindowAdapter() {
//            @Override
//            public void windowClosing(WindowEvent e) {
//                new Thread(new Runnable() {
//                    public void run() {
//                        System.exit(0);
//                    }
//                }).start();
//            }
//        });
//
//    }

    private void salvarMapa() {
        final String FILENAME = ".\\src\\jogo\\mapas\\sv\\mapa" + cntMapaSalvo
                + "_" + Jogo.MULT
                + "_" + mapa.getMapa_dim()
                + "_" + mapa.getParedes().size()
                + "_" + mapa.getTeleports().size()
                + "_" + (System.nanoTime() & 0xFFFFF) + ".txt";
        BufferedWriter bw = null;
        FileWriter fw = null;
        Map<String, Parede> paredes = mapa.getParedes();

        try {

            String content = MULT + System.lineSeparator();

            for (int i = 0; i <= mapa.getMapa_dim(); i++) {

                for (int j = 0; j <= mapa.getMapa_dim(); j++) {
                    if (paredes.containsKey(Parede.getNome(new Ponto(j, i)))) {
                        content += "*";
                    } else {
                        content += ".";
                    }
                }
                content += System.lineSeparator();
            }

            fw = new FileWriter(FILENAME);
            bw = new BufferedWriter(fw);
            bw.write(content);

            System.out.println("Done");

        } catch (IOException e) {

            e.printStackTrace();

        } finally {

            try {

                if (bw != null) {
                    bw.close();
                }

                if (fw != null) {
                    fw.close();
                }

            } catch (IOException ex) {

                ex.printStackTrace();

            }

        }

    }

}
