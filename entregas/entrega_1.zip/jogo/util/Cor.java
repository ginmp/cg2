/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo.util;

/**
 *
 * @author inmp
 */
public class Cor {

    private double r, g, b;

    public Cor(double r, double g, double b) {
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public Cor() {
        this(1, 1, 1);
    }

    public double getR() {
        return r;
    }

    public void setR(double r) {
        this.r = r;
    }

    public double getG() {
        return g;
    }

    public void setG(double g) {
        this.g = g;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    public int[] getIntRGB() {
        int[] rgb = new int[3];

        rgb[0] = (int) r * 256;
        rgb[1] = (int) g * 256;
        rgb[2] = (int) b * 256;

        rgb[0] ^= 256;
        rgb[1] ^= 256;
        rgb[2] ^= 256;
        return rgb;
    }

    public Cor getCorInvertida() {
        Cor cor;
        int[] rgb = getIntRGB();

        rgb[0] /= 256;
        rgb[1] /= 256;
        rgb[2] /= 256;

        cor = new Cor(rgb[0], rgb[1], rgb[2]);
        return cor;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 17 * hash + (int) (Double.doubleToLongBits(this.r) ^ (Double.doubleToLongBits(this.r) >>> 32));
        hash = 17 * hash + (int) (Double.doubleToLongBits(this.g) ^ (Double.doubleToLongBits(this.g) >>> 32));
        hash = 17 * hash + (int) (Double.doubleToLongBits(this.b) ^ (Double.doubleToLongBits(this.b) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cor other = (Cor) obj;
        if (Double.doubleToLongBits(this.r) != Double.doubleToLongBits(other.r)) {
            return false;
        }
        if (Double.doubleToLongBits(this.g) != Double.doubleToLongBits(other.g)) {
            return false;
        }
        if (Double.doubleToLongBits(this.b) != Double.doubleToLongBits(other.b)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Cor{" + "r=" + r + ", g=" + g + ", b=" + b + '}';
    }

}
