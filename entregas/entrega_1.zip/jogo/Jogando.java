/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

import jogo.controle.Controle;
import jogo.mapas.Mapa;

/**
 *
 * @author inmp
 */
public class Jogando implements IJogo {

    private Mapa mapa;
    private boolean rodadaPlayer1;

    public Jogando(Mapa mapa) {
        this.mapa = mapa;
    }

    private void player1Jogar() {

        Controle controle = mapa.getPlayer1().getControle();
        controle.setJogar(rodadaPlayer1);
        controle.jogar();

        rodadaPlayer1 = controle.isJogar();
    }

    private void player2Jogar() {
        Controle controle = mapa.getPlayer2().getControle();
//        controle.setJogar(!rodadaPlayer1);
        controle.jogar();

        rodadaPlayer1 = !controle.isJogar();
    }

   
@Override
    public void jogar() {
        if (rodadaPlayer1) {
            player1Jogar();
        } else {
            player2Jogar();
        }
    }

}
