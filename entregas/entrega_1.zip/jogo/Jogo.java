/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

import com.jme3.animation.AnimChannel;
import com.jme3.animation.AnimControl;
import com.jme3.animation.AnimEventListener;
import com.jme3.app.SimpleApplication;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.collision.PhysicsCollisionEvent;
import com.jme3.bullet.collision.PhysicsCollisionListener;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.bullet.util.CollisionShapeFactory;
import com.jme3.input.controls.ActionListener;
import com.jme3.light.AmbientLight;
import com.jme3.light.DirectionalLight;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.scene.Geometry;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Box;
import jogo.util.Cor;
import jogo.entidades.Base;
import jogo.entidades.Parede;
import jogo.mapas.Mapa;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import java.util.Map;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFrame;
import jogo.controle.BuildWall;
import jogo.controle.Controle;
import jogo.controle.ControlePlayer;
import jogo.controle.ControleGeral;
import jogo.entidades.Player;
import jogo.estrategias.ai.SeguirAI;
import jogo.mapas.gerador.GeradorMapa;
import jogo.mapas.gerador.GeradorSimples;
import jogo.util.Ponto;

/**
 *
 * @author inmp
 */
public class Jogo extends SimpleApplication
        implements PhysicsCollisionListener, AnimEventListener, ActionListener {
    
    private BulletAppState bulletAppState;
    private List<Spatial> paredes = new ArrayList<>();
    
    public static long FPS = 60;
    public static int MULT = 1;
    public static int RES = 1000;
    
    private int WIDTH = RES;
    private int HEIGHT = RES;
    
    private JFrame tela;
    private final int offset_tela_mapa = 11 * MULT;
    private double cam_dist = -20 * MULT;
    private double angCam = -5;
    
    private final Mapa mapa;
    
    private Jogando jogando;

    //Informacoes sobre a luz
    float luzAmbiente[] = {.2f, .2f, .2f, 1.0f};
    float luzDifusa[] = {.8f, .8f, .8f, .8f};	   // "cor"
    float luzEspecular[] = {.4f, .4f, .4f, 1.0f};// "brilho"
    float posicaoLuz[] = {-10.0f, 80.0f, 50.0f, 1.0f};

    // Informacoes sobre o material
    float especularidade[] = {.2f, .2f, .25f, 1.0f};
    int especMaterial = 0;
    double eqn[] = {-0.15, 0.15, 0, 0};
    
    private int camGiro;
    private int cntMapaSalvo;
    
    private ControleGeral controleGeral;
    
    private boolean rodadaPlayer1;
    private boolean mudarCamera;
    private boolean girarCamera;
    private boolean diminuirAngulo;
    private boolean aumentarAngulo;
    private boolean follow;
    private int angInicial;
    private boolean altAng;
    private boolean stop;
    
    public static void main(String[] args) {
        Jogo app = new Jogo();
       // app.showSettings = false;
        app.start();
    }
    
    @Override
    public void simpleInitApp() {
        
        bulletAppState = new BulletAppState();
        stateManager.attach(bulletAppState);
        bulletAppState.getPhysicsSpace().addCollisionListener(this);
        createLigth();
        desenharMapa();
        desenharPiso();
        desenharPlayer1();
        desenharPlayer2();
        
        System.out.println(getCamera().getLocation());
        
        this.getCamera().setLocation(new Vector3f(2*22*MULT, 5, 2*22*MULT));
 
    }
    
    @Override
    public void simpleUpdate(float tpf) {
        //TODO: add update code
    }
    
    @Override
    public void simpleRender(RenderManager rm) {
        //TODO: add render code
    }
    
    private void createLigth() {
        
        DirectionalLight l1 = new DirectionalLight();
        l1.setDirection(new Vector3f(1, -0.7f, 0));
        rootNode.addLight(l1);
        
        DirectionalLight l2 = new DirectionalLight();
        l2.setDirection(new Vector3f(-1, 0, 0));
        rootNode.addLight(l2);
        
        DirectionalLight l3 = new DirectionalLight();
        l3.setDirection(new Vector3f(0, 0, -1.0f));
        rootNode.addLight(l3);
        
        DirectionalLight l4 = new DirectionalLight();
        l4.setDirection(new Vector3f(0, 0, 1.0f));
        rootNode.addLight(l4);
        
        AmbientLight ambient = new AmbientLight();
        ambient.setColor(ColorRGBA.White);
        rootNode.addLight(ambient);
    }
    
    public Jogo() {
        initJogo();
        Controle controlePlayer1 = new ControlePlayer();
//        controlePlayer1 = new SeguirAI();

        Controle controlePlayer2 = new SeguirAI();
//        controlePlayer2 = new FugirAI_Melhorado();

        mapa = new Mapa(new GeradorSimples(), controlePlayer1, controlePlayer2);
        mapa.gerarMapa();
        
        if (controlePlayer1 instanceof ControlePlayer) {
            tela.addKeyListener((ControlePlayer) controlePlayer1);
        }
        jogando = new Jogando(mapa);
    }
    
    public Jogo(GeradorMapa gerador, Controle controlePlayer1, Controle controlePlayer2) {
        
        initJogo();
        mapa = new Mapa(gerador, controlePlayer1, controlePlayer2);
        mapa.gerarMapa();
        
        if (controlePlayer1 instanceof ControlePlayer) {
            tela.addKeyListener((ControlePlayer) controlePlayer1);
        }
        jogando = new Jogando(mapa);
                
    }
    
    private void initJogo() {
        
        createLigth();
        
        controleGeral = new ControleGeral();
        
        tela = new JFrame();
//        tela.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE); // fechar com botao direito : excessao
//        initTela(canvas);

        rodadaPlayer1 = true;
    }
    
    public void displa() {
        
        long duracao;
        
        duracao = System.nanoTime();
        
        Player player1 = mapa.getPlayer1();
        Player player2 = mapa.getPlayer2();
        if (player1.getControle() instanceof BuildWall) {
            BuildWall bw = (BuildWall) player1.getControle();
            if (bw.isBuild()) {
                // texto(gl, "P1 Paredes : " + bw.getParedes(), -6, 10.1);
            }
        }
        if (player2.getControle() instanceof BuildWall) {
            BuildWall bw = (BuildWall) player2.getControle();
            if (bw.isBuild()) {
                //texto(gl, "P2 Paredes : " + bw.getParedes(), 6, 10.1);
            }
        }

        // posicionarCamera(gl);
//        desenharPlayer1(gl);
//
//        desenharPlayer2(gl);
//
//        desenharTeleport(gl);


        if (!controleGeral.isPause()) {
            if (!stop) {
                jogando.jogar();
            }
        } else {

//            texto(gl, "ESC : continuar", -5, 8);
//            texto(gl, "Q : sair", -5, 7);
//
//            texto(gl, "S : salvar mapa" + (cntMapaSalvo > 0 ? " - salvo = " + cntMapaSalvo : ""), -5, -1);
//            texto(gl, "END : reiniciar", -5, 0);
//            texto(gl, "C : mudar camera", -5, 1);
//            texto(gl, "G : girar mapa", -5, 2);
//            texto(gl, "F : follow", -5, 3);
//            texto(gl, "PG_UP : camera girar+", -5, 4);
//            texto(gl, "PG_DOWN : camera girar-", -5, 5);
//            texto(gl, "BK_SPACE : tela config", -5, 6);
//
//            texto(gl, "Click : construir/destruir parede", -5, -3);
//            texto(gl, "DEL : ativar/desativar destruir parede = " + controleGeral.isDelete(), -5, -4);
//            texto(gl, "SHIFT : ativar/desativar construcao/destruicao continua = " + controleGeral.isShift(), -5, -5);
//            texto(gl, "R : sempre reiniciar = " + controleGeral.isSempreReiniciar(), -5, -6);
//            texto(gl, "1 2 : mover player 1 ou 2" + (controleGeral.isMoverP1() ? " = mover " + 1 : controleGeral.isMoverP2() ? " = mover " + 2 : ""), -5, -7);
        }
        
        if (mapa.isNovoMapa()) {
            
            if (controleGeral.isSempreReiniciar()) {
                controleGeral.reset();
                mapa.gerarMapa();
                stop = false;
                return;
            }
            stop = true;
            
        }
        
        follow = controleGeral.isFollow();
        
        if (!follow && altAng) {
            camGiro = angInicial;
            altAng = false;
        }
        if (controleGeral.isNovoMapa()) {
            controleGeral.reset();
            mapa.gerarMapa();
            stop = false;
            return;
        }
        
        if (controleGeral.isMudarCamera()) {
            cam_dist = -30 * MULT + MULT - 1;
            mudarCamera = true;
        } else {
            cam_dist = -20 * MULT + MULT - 1;
            mudarCamera = false;
        }
        
        if (controleGeral.isGirarCamera()) {
            girarCamera = true;
        }
        
        if (controleGeral.isAumentar()) {
            aumentarAngulo = true;
        }
        
        if (controleGeral.isDiminuir()) {
            diminuirAngulo = true;
        }
        
        if (controleGeral.isSair()) {
            System.exit(0);
        }
        
        if (!controleGeral.isMoverP1() && !controleGeral.isMoverP2()) {
            if (controleGeral.isShift()) {
                Ponto mp = controleGeral.getMousePoint();
                if (!mp.equals(player1.getPonto()) && !mp.equals(player2.getPonto())) {
                    if (!controleGeral.isDelete()) {
                        mapa.construirParede(mp, new Cor(0.6, 0.3, 0.15));
                    } else {
                        mapa.destruirParede(mp);
                    }
                }
            }
            
            if (controleGeral.isMouseClick()) {
                Ponto mp = controleGeral.getMousePoint();
                if (!mp.equals(player1.getPonto()) && !mp.equals(player2.getPonto())) {
                    if (!controleGeral.isDelete()) {
                        mapa.construirParede(mp, new Cor(0.6, 0.3, 0.15));
                    } else {
                        mapa.destruirParede(mp);
                    }
                }
            }
        } else if (controleGeral.isMoverP1()) {
            if (controleGeral.isMouseClick()) {
                Ponto mp = controleGeral.getMousePoint();
                if (!mapa.getParedes().containsKey(Parede.getNome(mp))) {
                    player1.setPonto(mp);
                    stop = player1.colisao(player2);
                    mapa.setNovoMapa(stop);
                    
                }
            }
        } else if (controleGeral.isMoverP2()) {
            if (controleGeral.isMouseClick()) {
                Ponto mp = controleGeral.getMousePoint();
                if (!mapa.getParedes().containsKey(Parede.getNome(mp))) {
                    player2.setPonto(mp);
                    stop = player1.colisao(player2);
                    mapa.setNovoMapa(stop);
                }
            }
        }
        
        if (controleGeral.isSalvar()) {
            salvarMapa();
            cntMapaSalvo++;
        }
        if (controleGeral.isFpsAdd() && FPS < 300) {
            FPS++;
        } else if (controleGeral.isFpsSub() && FPS > 1) {
            FPS--;
        }
//        texto(gl, "" + FPS, 6, -8);

        duracao = System.nanoTime() - duracao;
        sleep(duracao);
        
        if (controleGeral.isTelaConfig()) {
            destroy();
        }
    }
    
    private void desenharPiso() {

        String name = "piso";
        Box boxMesh = new Box(23 * MULT, 1, 23 * MULT);
        //Box boxMesh = new Box(2, -1, 2);
        Geometry boxGeo = new Geometry(name, boxMesh);
        Material boxMat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        boxMat.setTexture("ColorMap", assetManager.loadTexture("Textures/grass.jpg"));
        
        boxGeo.setMaterial(boxMat);
        
        boxGeo.setLocalTranslation(22 * MULT, -2, 22 * MULT);
        
        rootNode.attachChild(boxGeo);
        
        RigidBodyControl boxPhysicsNode = new RigidBodyControl(CollisionShapeFactory.createMeshShape(boxGeo), 0);
        boxGeo.addControl(boxPhysicsNode);
        bulletAppState.getPhysicsSpace().add(boxPhysicsNode);
        
    }
    
    private void desenharMapa() {
        
        float dim = 1f;
        //posicionarCamera(gl);
        for (Parede p : mapa.getParedes().values()) {
            String name = "parede";
            Box boxMesh = new Box(dim, dim, dim);
            Geometry boxGeo = new Geometry(name, boxMesh);
            Material boxMat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
            boxMat.setTexture("ColorMap", assetManager.loadTexture("Textures/cedrinho.jpg"));
            
            boxGeo.setMaterial(boxMat);
            
            boxGeo.setLocalTranslation(2 * p.getX(), p.getZ(), 2 * p.getY());
            
            rootNode.attachChild(boxGeo);
            
            RigidBodyControl boxPhysicsNode = new RigidBodyControl(CollisionShapeFactory.createMeshShape(boxGeo), 0);
            boxGeo.addControl(boxPhysicsNode);
            bulletAppState.getPhysicsSpace().add(boxPhysicsNode);
            
            paredes.add(boxGeo);
        }
    }
    
    private void desenharPlayer1() {
        Spatial player = assetManager.loadModel("Models/Oto/Oto.mesh.xml");
        player.setName("p1");
        
        float dim = .25f;
        player.setLocalScale(dim, dim, dim);
        translatedBase(player, mapa.getPlayer1(), .15f);
        rootNode.attachChild(player);
        
    }
    
    private void desenharPlayer2() {
        Spatial player
                = assetManager.loadModel("Models/Ninja/Ninja.mesh.xml");
        //assetManager.loadModel("Models/gltf/duck/Duck.gltf");
        player.setName("p2");
        float dim = .015f;
        player.setLocalScale(dim, dim, dim);
        translatedBase(player, mapa.getPlayer2(), -1f);
        rootNode.attachChild(player);
    }
    
    private void translatedBase(Spatial sp, Base base, float z) {
        float offset = .75f;
        sp.setLocalTranslation((base.getX()) * 2, z, (base.getY()) * 2);
        
    }
//
//    private void player1Jogar() {
//
//        Controle controle = mapa.getPlayer1().getControle();
//        controle.setJogar(rodadaPlayer1);
//        controle.jogar();
//
//        rodadaPlayer1 = controle.isJogar();
//    }
//
//    private void player2Jogar() {
//        Controle controle = mapa.getPlayer2().getControle();
////        controle.setJogar(!rodadaPlayer1);
//        controle.jogar();
//
//        rodadaPlayer1 = !controle.isJogar();
//    }
//
//    private void texto(GL2 gl, String str, double x, double y) {
//
//        gl.glPushMatrix();
//        {
//            gl.glLoadIdentity();
//
//            gl.glTranslated(0, 0, -20);
//            gl.glTranslated(x, y, 3);
//
//            gl.glColor3d(1, .8, .2);
//
//            gl.glDisable(GL2.GL_LIGHTING);
//
//            glu.gluOrtho2D(0, WIDTH, 0, HEIGHT);
//            gl.glRasterPos2i(0, 0);
//
//            gl.glEnable(GL2.GL_LIGHTING);
//
//            glut.glutBitmapString(GLUT.BITMAP_TIMES_ROMAN_24, str);
//        }
//        gl.glPopMatrix();
//
//    }
//
//    private void initTela(Component canvas) {
//        tela.setSize(WIDTH, HEIGHT);
//        tela.setResizable(false);
//        tela.setUndecorated(true);
//
//        tela.getContentPane().add(canvas);
//
//        tela.setVisible(true);
//
//        tela.setLocation(
//                (int) (Toolkit.getDefaultToolkit().getScreenSize().getWidth()) / 2
//                - tela.getWidth() / 2,
//                (int) (Toolkit.getDefaultToolkit().getScreenSize().getHeight()) / 2
//                - tela.getHeight() / 2);
//        tela.setAlwaysOnTop(true);
//
//        tela.addKeyListener(controleGeral);
//        tela.addMouseListener(controleGeral);
//        tela.addMouseMotionListener(controleGeral);
//
//        tela.addWindowListener(new WindowAdapter() {
//            @Override
//            public void windowClosing(WindowEvent e) {
//                new Thread(new Runnable() {
//                    public void run() {
//                        System.exit(0);
//                    }
//                }).start();
//            }
//        });
//
//    }

    private long getEspera(long duracao) {
        duracao = (long) (1e3 * (1e0 - duracao * FPS * 1e-9) / FPS);
        return duracao > 0 ? duracao : 0;
    }
    
    private void sleep(long duracao) {
        try {
            Thread.sleep(getEspera(duracao));
            
        } catch (InterruptedException ex) {
            Logger.getLogger(Jogo.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private void salvarMapa() {
        final String FILENAME = ".\\src\\jogo\\mapas\\sv\\mapa" + cntMapaSalvo
                + "_" + Jogo.MULT
                + "_" + mapa.getMapa_dim()
                + "_" + mapa.getParedes().size()
                + "_" + mapa.getTeleports().size()
                + "_" + (System.nanoTime() & 0xFFFFF) + ".txt";
        BufferedWriter bw = null;
        FileWriter fw = null;
        Map<String, Parede> paredes = mapa.getParedes();
        
        try {
            
            String content = MULT + System.lineSeparator();
            
            for (int i = 0; i <= mapa.getMapa_dim(); i++) {
                
                for (int j = 0; j <= mapa.getMapa_dim(); j++) {
                    if (paredes.containsKey(Parede.getNome(new Ponto(j, i)))) {
                        content += "*";
                    } else {
                        content += ".";
                    }
                }
                content += System.lineSeparator();
            }
            
            fw = new FileWriter(FILENAME);
            bw = new BufferedWriter(fw);
            bw.write(content);
            
            System.out.println("Done");
            
        } catch (IOException e) {
            
            e.printStackTrace();
            
        } finally {
            
            try {
                
                if (bw != null) {
                    bw.close();
                }
                
                if (fw != null) {
                    fw.close();
                }
                
            } catch (IOException ex) {
                
                ex.printStackTrace();
                
            }
            
        }
        
    }
    
    @Override
    public void collision(PhysicsCollisionEvent event) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public void onAnimCycleDone(AnimControl control, AnimChannel channel, String animName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public void onAnimChange(AnimControl control, AnimChannel channel, String animName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public void onAction(String name, boolean isPressed, float tpf) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
